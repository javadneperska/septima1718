package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int a, b, vys;
        Scanner scan = new Scanner(System.in);

        System.out.print("Vloz dve cisla : ");
        a = scan.nextInt();
        b = scan.nextInt();

        vys = a + b;
        System.out.println("Scitanie = " +vys);

        vys = a - b;
        System.out.println("Odcitanie = " +vys);

        vys = a * b;
        System.out.println("Nasobenie = " +vys);

        vys = a / b;
        System.out.println("Delenie = " +vys);
    }
}


